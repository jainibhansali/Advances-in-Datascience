### In this directory you will find the Exploratory Data Analysis that we did for the project Instacart Market Basket Analysis
### The file EDA Instacart(1).ipynb contains the eda done on the jupyter notebook along with the findings from those EDA's
### The folder Tableau contains all the tableau visualizations we created for EDA and Summary Metrics
