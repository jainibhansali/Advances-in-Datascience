### This Directory contains the ipynb files that we ran on the google cloud platform to get the results
The resultset consist of columns antecedants, consequents,support,lift, confidence, conviction for each associated product
All the algorithm in this directory were ran on the data clustered on basis of department since we saw that in an order about 40% of the products belonged to the same department

Please refer to the documentation for more details
