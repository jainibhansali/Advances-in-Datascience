#### This Directory Contains the code and the files needed to create your own web application similar to ours
#### Apart from the web application we are also uploading an azurescript.py which has links and api_key to all the models that we built and deployed on Azure


Please have all the dependencies present or follow the following steps

    1. Install Python 2.7
    2. Install pip
    3. pip install urllib3
    4. pip install numpy
    5. pip install pandas
    6. pip install Flask
    
    To run the application type in python __init__.py
    
  
